// CutsceneCommand.java
package com.example.storytell.init.cutscene;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

public class CutsceneCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("cutscene")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("folder", StringArgumentType.string())
                        .executes(context -> {
                            String folderName = StringArgumentType.getString(context, "folder");
                            ServerPlayer player = context.getSource().getPlayerOrException();

                            // Воспроизводим музыку для всех игроков в зависимости от катсцены
                            String soundName = "storytell:music"; // по умолчанию

                            if ("1".equals(folderName)) {
                                soundName = "storytell:music_1";
                            }
                            // Можно добавить другие условия для других катсцен

                            context.getSource().getServer().getCommands()
                                    .performPrefixedCommand(context.getSource(),
                                            "playsound " + soundName + " master @a");

                            // Отправляем пакет клиенту для запуска катсцены
                            CutsceneNetworkHandler.INSTANCE.send(
                                    PacketDistributor.PLAYER.with(() -> player),
                                    new CutsceneStartPacket(folderName)
                            );

                            return 1;
                        })));
    }
}