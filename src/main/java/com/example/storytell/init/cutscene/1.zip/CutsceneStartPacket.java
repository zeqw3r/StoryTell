// CutsceneStartPacket.java
package com.example.storytell.init.cutscene;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class CutsceneStartPacket {
    private final String folderName;

    public CutsceneStartPacket(String folderName) {
        this.folderName = folderName;
    }

    public CutsceneStartPacket(FriendlyByteBuf buf) {
        this.folderName = buf.readUtf();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeUtf(folderName);
    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // Запускаем катсцену на клиенте
            CutsceneManager.getInstance().startCutscene(folderName);
        });
        return true;
    }
}