// Cutscene.java
package com.example.storytell.init.cutscene;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import java.util.ArrayList;
import java.util.List;

public class Cutscene {
    private static final int DELAY_BETWEEN_IMAGES = 100; // 5 секунд в тиках (20 тиков = 1 секунда)
    private static final int FADE_DURATION = 20; // Длительность анимации в тиках (1 секунда)
    private static final ResourceLocation DEFAULT_BACKGROUND = new ResourceLocation("storytell", "textures/cutscene/background.png");

    private final String folderName;
    private final List<ResourceLocation> images;
    private final List<Float> imageAlphas; // Прозрачность для каждой картинки
    private int currentImageIndex;
    private int timer;
    private boolean active;

    public Cutscene(String folderName) {
        this.folderName = folderName;
        this.images = new ArrayList<>();
        this.imageAlphas = new ArrayList<>();
        this.currentImageIndex = -1;
        this.timer = 0;
        this.active = false;
        loadImages();
    }

    private void loadImages() {
        // Загружаем изображения из папки ресурсов
        String basePath = "textures/cutscene/" + folderName + "/";

        int imageNumber = 1;
        while (true) {
            ResourceLocation imageLocation = new ResourceLocation("storytell", basePath + imageNumber + ".png");

            // Более надежная проверка существования ресурса
            try {
                // Пытаемся загрузить текстуру через менеджер ресурсов
                var resource = Minecraft.getInstance().getResourceManager().getResource(imageLocation);
                if (resource.isPresent()) {
                    images.add(imageLocation);
                    imageAlphas.add(0.0f); // Начальная прозрачность 0
                    System.out.println("Successfully loaded cutscene image: " + imageLocation);
                    imageNumber++;
                } else {
                    break;
                }
            } catch (Exception e) {
                System.out.println("Could not load image " + imageNumber + " for cutscene: " + e.getMessage());
                break;
            }
        }

        // Если изображения не найдены, выводим сообщение в лог
        if (images.isEmpty()) {
            System.out.println("No cutscene images found in folder: " + folderName);
            System.out.println("Expected path: assets/storytell/textures/cutscene/" + folderName + "/");
            System.out.println("Make sure images are named 1.png, 2.png, etc.");
        } else {
            System.out.println("Loaded " + images.size() + " images for cutscene: " + folderName);
        }
    }

    public void start() {
        this.active = true;
        this.currentImageIndex = 0;
        this.timer = 0;
    }

    public void stop() {
        this.active = false;
        this.currentImageIndex = -1;
    }

    public void tick() {
        if (!active) return;

        timer++;

        // Обновляем анимации прозрачности для всех картинок
        for (int i = 0; i < images.size(); i++) {
            float currentAlpha = imageAlphas.get(i);

            if (i == currentImageIndex) {
                // Текущая картинка - плавно появляется
                if (currentAlpha < 1.0f) {
                    float newAlpha = Math.min(1.0f, currentAlpha + (1.0f / FADE_DURATION));
                    imageAlphas.set(i, newAlpha);
                }
            } else if (i < currentImageIndex) {
                // Предыдущие картинки - остаются полностью видимыми
                if (currentAlpha < 1.0f) {
                    imageAlphas.set(i, 1.0f);
                }
            } else {
                // Следующие картинки - остаются невидимыми
                if (currentAlpha > 0.0f) {
                    imageAlphas.set(i, 0.0f);
                }
            }
        }

        // Переход к следующей картинке через заданное время
        if (timer >= DELAY_BETWEEN_IMAGES) {
            timer = 0;
            currentImageIndex++;

            if (currentImageIndex >= images.size()) {
                stop();
            }
        }
    }

    public void render(GuiGraphics guiGraphics) {
        if (!active || currentImageIndex < 0 || currentImageIndex >= images.size()) return;

        Minecraft minecraft = Minecraft.getInstance();
        int width = minecraft.getWindow().getGuiScaledWidth();
        int height = minecraft.getWindow().getGuiScaledHeight();

        // Рендерим кастомный фон вместо черного экрана
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        // Проверяем, существует ли кастомный фон
        boolean customBackgroundExists = Minecraft.getInstance()
                .getResourceManager()
                .getResource(DEFAULT_BACKGROUND)
                .isPresent();

        if (customBackgroundExists) {
            guiGraphics.blit(DEFAULT_BACKGROUND, 0, 0, 0, 0, width, height, width, height);
        } else {
            // Если кастомный фон не найден, используем черный
            guiGraphics.fill(0, 0, width, height, 0xFF000000);
        }

        // Рендерим все изображения с их текущей прозрачностью
        for (int i = 0; i <= currentImageIndex; i++) {
            if (i < images.size()) {
                float alpha = imageAlphas.get(i);
                if (alpha > 0.0f) {
                    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
                    guiGraphics.blit(images.get(i), 0, 0, 0, 0, width, height, width, height);
                }
            }
        }

        // Сбрасываем цвет шейдера
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public boolean hasImages() {
        return !images.isEmpty();
    }
}