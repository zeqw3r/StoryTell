// CutsceneCommand.java
package com.example.storytell.init.cutscene;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

public class CutsceneCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("cutscene")
                .requires(source -> source.hasPermission(2))
                .then(Commands.argument("folder", StringArgumentType.string())
                        .executes(context -> {
                            String folderName = StringArgumentType.getString(context, "folder");
                            ServerPlayer player = context.getSource().getPlayerOrException();

                            // Воспроизводим музыку для всех игроков
                            context.getSource().getServer().getCommands()
                                    .performPrefixedCommand(context.getSource(),
                                            "playsound storytell:music master @a");

                            // Отправляем пакет клиенту для запуска катсцены
                            CutsceneNetworkHandler.INSTANCE.send(
                                    PacketDistributor.PLAYER.with(() -> player),
                                    new CutsceneStartPacket(folderName)
                            );

                            return 1;
                        })));
    }
}