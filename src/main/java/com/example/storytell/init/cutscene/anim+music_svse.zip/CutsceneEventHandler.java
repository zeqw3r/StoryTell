// CutsceneEventHandler.java
package com.example.storytell.init.cutscene;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "storytell", value = Dist.CLIENT)
public class CutsceneEventHandler {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            CutsceneManager.getInstance().tick();
        }
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        if (CutsceneManager.getInstance().isCutscenePlaying()) {
            CutsceneManager.getInstance().render(event.getGuiGraphics());
        }
    }
}