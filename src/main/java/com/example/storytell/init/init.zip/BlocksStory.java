package com.example.storytell.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;

import javax.annotation.Nullable;
import java.awt.*;

public class BlocksStory extends Block {
    public BlocksStory(){
        super(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK));
    }

}
