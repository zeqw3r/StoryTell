package com.example.storytell.init.shake;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.*;

@Mod.EventBusSubscriber
public class ScreenShakeHandler {

    private static final Map<UUID, ShakeData> ACTIVE_SHAKES = new HashMap<>();
    private static final Random RANDOM = new Random();

    public static void applyScreenShake(ServerPlayer player, float power, int duration) {
        // Initialize objectives if needed
        initializeObjectives(player.getScoreboard());

        // Set initial values (как в датапаке)
        setPlayerScore(player, "ss.timer", duration);
        setPlayerScore(player, "ss.coefficient1", (int)(power * 100));
        setPlayerScore(player, "ss.coefficient2", (int)(power * 50));

        // Set constants
        setGlobalScore(player.getScoreboard(), "2", "ss.const", 2);
        setGlobalScore(player.getScoreboard(), "-1", "ss.const", -1);
        setGlobalScore(player.getScoreboard(), "max", "random", 2001);

        ACTIVE_SHAKES.put(player.getUUID(), new ShakeData(power, duration));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            processScreenShakes();
        }
    }

    private static void processScreenShakes() {
        Iterator<Map.Entry<UUID, ShakeData>> iterator = ACTIVE_SHAKES.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<UUID, ShakeData> entry = iterator.next();
            UUID playerId = entry.getKey();
            ShakeData data = entry.getValue();

            ServerPlayer player = getPlayerByUUID(playerId);
            if (player == null) {
                iterator.remove();
                continue;
            }

            int timer = getPlayerScore(player, "ss.timer");
            if (timer <= 0) {
                iterator.remove();
                continue;
            }

            executeShakeLogic(player);
            setPlayerScore(player, "ss.timer", timer - 1);
            data.duration = timer - 1;
        }
    }

    private static void executeShakeLogic(ServerPlayer player) {
        int timer = getPlayerScore(player, "ss.timer");
        int coefficient1 = getPlayerScore(player, "ss.coefficient1");
        int coefficient2 = getPlayerScore(player, "ss.coefficient2");

        int timerParity = timer % 2;

        if (timerParity == 0) {
            // Even tick logic
            executeEvenTickLogic(player, timer, coefficient1, coefficient2);
        } else {
            // Odd tick logic
            executeOddTickLogic(player);
        }

        applyShakeEffect(player);
    }

    private static void executeEvenTickLogic(ServerPlayer player, int timer, int coefficient1, int coefficient2) {
        // Δyaw = timer * coefficient1 + coefficient2
        int deltaYaw = timer * coefficient1 + coefficient2;
        int deltaPitch = deltaYaw;

        // Generate random coefficients (аналогично random:next в датапаке)
        int random1 = RANDOM.nextInt(2001) - 1000; // -1000 to 1000
        int random2 = RANDOM.nextInt(2001) - 1000;

        // Apply random factors: Δyaw *= random1, Δpitch *= random2
        deltaYaw = deltaYaw * random1 / 1000;
        deltaPitch = deltaPitch * random2 / 1000;

        // Store values for odd tick
        setPlayerScore(player, "ss.dyaw", deltaYaw);
        setPlayerScore(player, "ss.dpitch", deltaPitch);
    }

    private static void executeOddTickLogic(ServerPlayer player) {
        // Use stored values and invert (как в shake/odd.mcfunction)
        int deltaYaw = -getPlayerScore(player, "ss.dyaw");
        int deltaPitch = -getPlayerScore(player, "ss.dpitch");

        setPlayerScore(player, "ss.dyaw", deltaYaw);
        setPlayerScore(player, "ss.dpitch", deltaPitch);
    }

    private static void applyShakeEffect(ServerPlayer player) {
        // Get current rotation
        float currentYaw = player.getYRot();
        float currentPitch = player.getXRot();

        // Get delta values
        int deltaYaw = getPlayerScore(player, "ss.dyaw");
        int deltaPitch = getPlayerScore(player, "ss.dpitch");

        // Convert to rotation changes - УВЕЛИЧИЛИ тряску, уменьшив делитель с 100000 до 50000
        float yawChange = deltaYaw / 50000.0f;
        float pitchChange = deltaPitch / 50000.0f;

        // Calculate new rotation
        float newYaw = currentYaw + yawChange;
        float newPitch = currentPitch + pitchChange;

        // Ensure pitch stays within valid bounds
        newPitch = Math.max(-90.0f, Math.min(90.0f, newPitch));

        // Apply using AreaEffectCloud (как в датапаке)
        AreaEffectCloud cloud = new AreaEffectCloud(player.level(),
                player.getX(), player.getY(), player.getZ());
        cloud.setRadius(0.1f);
        cloud.setWaitTime(0);
        cloud.setDuration(2);
        cloud.setFixedColor(0xFF0000);

        cloud.setYRot(newYaw);
        cloud.setXRot(newPitch);

        player.level().addFreshEntity(cloud);

        // Teleport player to cloud (применяя поворот)
        player.teleportTo(
                player.getServer().overworld(),
                player.getX(), player.getY(), player.getZ(),
                newYaw, newPitch
        );

        cloud.discard();
        player.connection.resetPosition();
    }

    public static void initializeObjectives(Scoreboard scoreboard) {
        String[] objectives = {
                "random", "ss.coefficient1", "ss.coefficient2", "ss.timer",
                "ss.var", "ss.const", "ss.dyaw", "ss.dpitch"
        };

        for (String objective : objectives) {
            if (scoreboard.getObjective(objective) == null) {
                scoreboard.addObjective(
                        objective,
                        ObjectiveCriteria.DUMMY,
                        net.minecraft.network.chat.Component.literal(objective),
                        ObjectiveCriteria.RenderType.INTEGER
                );
            }
        }

        setGlobalScore(scoreboard, "2", "ss.const", 2);
        setGlobalScore(scoreboard, "-1", "ss.const", -1);
        setGlobalScore(scoreboard, "max", "random", 2001);
    }

    private static void setPlayerScore(ServerPlayer player, String objective, int value) {
        Scoreboard scoreboard = player.getScoreboard();
        Objective obj = scoreboard.getObjective(objective);
        if (obj != null) {
            scoreboard.getOrCreatePlayerScore(player.getScoreboardName(), obj).setScore(value);
        }
    }

    public static void setGlobalScore(Scoreboard scoreboard, String playerName, String objective, int value) {
        Objective obj = scoreboard.getObjective(objective);
        if (obj != null) {
            scoreboard.getOrCreatePlayerScore(playerName, obj).setScore(value);
        }
    }

    private static int getPlayerScore(ServerPlayer player, String objective) {
        Scoreboard scoreboard = player.getScoreboard();
        Objective obj = scoreboard.getObjective(objective);
        if (obj != null) {
            return scoreboard.getOrCreatePlayerScore(player.getScoreboardName(), obj).getScore();
        }
        return 0;
    }

    private static ServerPlayer getPlayerByUUID(UUID uuid) {
        try {
            return ServerLifecycleHooks.getCurrentServer().getPlayerList().getPlayer(uuid);
        } catch (Exception e) {
            return null;
        }
    }

    private static class ShakeData {
        public float power;
        public int duration;

        public ShakeData(float power, int duration) {
            this.power = power;
            this.duration = duration;
        }
    }
}