// OrbitalStrikeParticles.java
package com.example.storytell.init.strike;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.Random;

public class OrbitalStrikeParticles {
    private static final Random RANDOM = new Random();

    public static void createBeamParticles(ServerLevel level, Vec3 start, Vec3 end, int count) {
        Vec3 direction = end.subtract(start).normalize();
        double distance = start.distanceTo(end);

        for (int i = 0; i < count; i++) {
            double progress = RANDOM.nextDouble();
            Vec3 particlePos = start.add(direction.scale(distance * progress));

            // Красные частицы для луча
            level.sendParticles(new DustParticleOptions(
                            new Vector3f(1.0f, 0.0f, 0.0f), 1.0f),
                    particlePos.x, particlePos.y, particlePos.z,
                    1, 0.1, 0.1, 0.1, 0.01);
        }
    }

    public static void createShockwaveParticles(ServerLevel level, Vec3 center, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            double x = center.x + Math.cos(angle) * radius;
            double z = center.z + Math.sin(angle) * radius;

            level.sendParticles(ParticleTypes.SONIC_BOOM,
                    x, center.y + 1, z, 1, 0, 0, 0, 0);
        }
    }

    public static void createFireParticles(ServerLevel level, Vec3 center, double radius, int count) {
        for (int i = 0; i < count; i++) {
            double angle = RANDOM.nextDouble() * 2 * Math.PI;
            double distance = RANDOM.nextDouble() * radius;

            double x = center.x + Math.cos(angle) * distance;
            double z = center.z + Math.sin(angle) * distance;
            double y = center.y + RANDOM.nextDouble() * 3;

            level.sendParticles(ParticleTypes.FLAME,
                    x, y, z, 1, 0.1, 0.1, 0.1, 0.02);

            level.sendParticles(ParticleTypes.SMOKE,
                    x, y, z, 1, 0.2, 0.2, 0.2, 0.01);
        }
    }
}