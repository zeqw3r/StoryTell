// ScreenShakeHandler.java
package com.example.storytell.init.strike;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.*;

public class ScreenShakeHandler {
    private static final Map<UUID, ShakeData> SHAKING_PLAYERS = new HashMap<>();
    private static final Random RANDOM = new Random();

    public static void applyScreenShake(ServerPlayer player, int durationTicks, float intensity) {
        SHAKING_PLAYERS.put(player.getUUID(), new ShakeData(player.getUUID(), durationTicks, intensity));
    }

    public static void tick() {
        Iterator<Map.Entry<UUID, ShakeData>> iterator = SHAKING_PLAYERS.entrySet().iterator();
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();

        while (iterator.hasNext()) {
            Map.Entry<UUID, ShakeData> entry = iterator.next();
            ShakeData data = entry.getValue();

            if (data.remainingTicks <= 0) {
                iterator.remove();
                continue;
            }

            ServerPlayer player = data.getPlayer(server);
            if (player != null) {
                float yawOffset = (RANDOM.nextFloat() - 0.5f) * data.intensity;
                float pitchOffset = (RANDOM.nextFloat() - 0.5f) * data.intensity * 0.5f;

                player.setYRot(player.getYRot() + yawOffset);
                player.setXRot(player.getXRot() + pitchOffset);
                player.connection.resetPosition();
            }

            data.remainingTicks--;
        }
    }

    private static class ShakeData {
        public int remainingTicks;
        public final float intensity;
        private final UUID playerId;

        public ShakeData(UUID playerId, int durationTicks, float intensity) {
            this.playerId = playerId;
            this.remainingTicks = durationTicks;
            this.intensity = intensity;
        }

        public ServerPlayer getPlayer(MinecraftServer server) {
            return server.getPlayerList().getPlayer(playerId);
        }
    }
}